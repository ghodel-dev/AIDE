package $package_name$;

import android.app.Application;

class App : Application() {

	companion object {

		private val App sApp;

		public static getApp() : App {
			return sApp;
		}

	}

	override fun onCreate() {
		super.onCreate();
		sApp = this;
	}

}
