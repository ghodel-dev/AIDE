package $package_name$.activity;

import androidx.appcompat.app.AppCompatActivity;
import $package_name$.R;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_main);
		super.onCreate(savedInstanceState);
		
	}

}
